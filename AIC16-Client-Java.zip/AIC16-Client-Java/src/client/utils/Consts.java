package client.utils;

/**
 * Created by iman on 2/11/16.
 */
public class Consts {
	public static final int INF = (int)1e6;
}
