package client.utils;

import client.scoring.NodePriority;
import junit.framework.TestCase;

/**
 * Created by iman on 2/12/16.
 *
 * Test For NodePriority Class
 */
public class NodePriorityTest extends TestCase {

	public void testNodeTypeComparing(){
//		assertEquals(new Integer(1).compareTo(8) / Math.abs(new Integer(1).compareTo(8)),
//				NodePriority.ALLY_OVERFILL.compareTo(NodePriority.ALLY_IN_DANGER) /
//						Math.abs(NodePriority.ALLY_OVERFILL.compareTo(NodePriority.ALLY_IN_DANGER)));
//		System.out.println(NodePriority.ALLY_OVERFILL.compareTo(NodePriority.ALLY_IN_DANGER));
	}

}